﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace OnionContactManagementSolution.DataAccess.Migrations
{
    public partial class contact31021 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
