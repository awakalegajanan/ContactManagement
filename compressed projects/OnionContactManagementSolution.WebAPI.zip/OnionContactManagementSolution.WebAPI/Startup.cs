﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using OnionContactManagementSolution.Application;
using OnionContactManagementSolution.Core.Interfaces;
using OnionContactManagementSolution.Core.Logging;
using OnionContactManagementSolution.DataAccess.Context;
using OnionContactManagementSolution.Logging;
using OnionContactManagementSolution.WebAPI.Exception;

namespace OnionContactManagementSolution.WebAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            
            services.AddSwaggerGen(s =>
            {
                
                s.IncludeXmlComments(string.Format(@"{0}\Swagger.xml", System.AppDomain.CurrentDomain.BaseDirectory));
                s.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "Onion Contact Management Solution",
                });               
            });

            string dbConnection = Configuration.GetValue<string>("Database");
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString(dbConnection)));

            services.AddScoped<IApplicationDbContext, ApplicationDbContext>();
            services.AddTransient<IContactOperations, ContactOperations>();
            services.AddSingleton<ILoggerInterface, Logger>();

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseMiddleware<CustomExceptionMiddleware>();
            app.UseMvc();
            app.UseSwagger();
            app.UseSwaggerUI(s =>
            {
                s.SwaggerEndpoint("v1/swagger.json", "Web API Version - v1");
            });

        }
    }
}
